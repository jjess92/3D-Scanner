<!---
This form is intended mainly for bug reports and feature requests. 
This is NOT the place to ask for general project help. If you need help, please use the community forum available [here](http://community.scanse.io/).

Tips for posting an issue:
    Include the verison of the sweep firmware you are using.
    Describe the bug or feature request in detail. 
    Explain what happened and what you expected to happen.
    If relevant, a code snippet, screenshot, or small-test can help people understand.

This text is a "template". Feel free to delete it.
-->



